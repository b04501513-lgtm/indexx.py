# CS2 Skin Market Telegram Bot

Telegram bot for posting CS2 skins to a channel with admin approval and payment proof.

## Features
- Sell CS2 skins
- Send skin info and photo
- Payment proof system
- Admin approve/reject
- Auto post to Telegram channel

## Installation

pip install -r requirements.txt

## Run

python bot/main.py

## Config
Edit config.py file:
- BOT_TOKEN
- ADMIN_ID
- CHANNEL_ID
- ADMIN_CARD
